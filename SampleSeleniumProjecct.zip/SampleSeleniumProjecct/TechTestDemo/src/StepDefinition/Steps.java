package StepDefinition;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

import java.util.List;
import java.util.Map;

import SeleniumPages.Utils;
import cucumber.api.java.en.Then;

public class Steps {
	Utils utilsPage = new Utils();

	@Given("^User launched the browser$")
	public void user_launched_the_browser() throws Exception {
		utilsPage.launchBrowser();
	}

	@When("^user open the search engine$")
	public void user_open_the_search_engine() throws Exception {
		utilsPage.openSearchEngine();
	}
	
	@When("^user search for the searchterm as \"(.*?)\"$")
	public void user_search_for_the_searchterm_as(String searchfield) throws Exception {
		utilsPage.executeSearch(searchfield);
	}
	@Then("^verify TruNarrative is the first search result and it points to \"(.*?)\"$")
	public void verify_TruNarrative_is_the_first_search_result_and_it_points_to(String url) throws Exception {
		utilsPage.searchTermReturnedFirst(url);
	}
	@Given("^user clicks on the TruNarrative link$")
	public void user_clicks_on_the_TruNarrative_link() throws Exception {
		utilsPage.hitUrl();
	}

	@When("^user navigated to TruNarrative website$")
	public void user_navigated_to_TruNarrative_website() throws Exception {
		utilsPage.websiteNavigation();
	}

	@Then("^Verify strap line is found on the page$")
	public void verify_strap_line_is_found_on_the_page() throws Exception {
		utilsPage.checkStrapLine();
	}
	

	@Given("^user can clicks on MORE link$")
	public void user_can_clicks_on_MORE_link() throws Exception {
		utilsPage.hitMore();
	}
	
	@When("^user clicks on TRUNARRATIVE TEAM link$")
	public void user_clicks_on_TRUNARRATIVE_TEAM_link() throws Exception {
		utilsPage.hitTrunarrativeTeam();
	}
	
	@Then("^Verify user can see the TruNarrative leadership team consisting of nine members$")
	public void verify_user_can_see_the_TruNarrative_leadership_team_consisting_of_nine_members() throws Exception {
		utilsPage.checkTeamCount();
	}
	
	@Then("^VErify user can see the roles of John Lord as FOUNDER AND CEO, David Estaugh as CTO and Nicola Janney as HUMAN RESOURCE MANAGER$")
	public void verify_user_can_see_the_roles_of_John_Lord_as_FOUNDER_AND_CEO_David_Estaugh_as_CTO_and_Nicola_Janney_as_HUMAN_RESOURCE_MANAGER() throws Exception {
		utilsPage.checkRoles();
	}

}



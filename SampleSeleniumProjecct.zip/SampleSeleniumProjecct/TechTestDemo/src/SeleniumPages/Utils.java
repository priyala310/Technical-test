package SeleniumPages;

import Common.BasePage;
import org.junit.Assert;
import net.bytebuddy.asm.Advice.Enter;
import net.bytebuddy.asm.Advice.Return;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Utils extends BasePage{

	
	public void launchBrowser() {
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumProject\\SampleSeleniumProjecct\\chromedriverpath\\chromedriver.exe");
		driver = new ChromeDriver();
		
	}
	public void openSearchEngine() {
		String appUrl = "https://www.google.com";
		driver.get(appUrl);
		driver.manage().window().maximize();
	}
	public void executeSearch(String searchTerm) {
		WebElement searchField = driver.findElement(By.name("q"));
		searchField.sendKeys(searchTerm);
		WebElement searchButton = driver.findElement(By.name("btnK"));
		searchButton.click();
	    WebElement searchResults =  driver.findElement(By.id("resultStats"));
	    if(searchResults.isDisplayed()) {
	    	System.out.println("Search is executed");
	    } else {
            System.out.println("Search is NOT executed");
	    }
	}
	public void searchTermReturnedFirst(String url) {
		List<WebElement> results = driver.findElements(By.id("search"));
				
		WebElement b = results.get(0);
		System.out.println("first result" + b);
		
		WebElement resUrlTag = b.findElement(By.tagName("cite"));
		String resUrl = resUrlTag.getText();
		
		if(resUrl.contains(url)) {
			
			System.out.println("Search term returned first and it points to https://trunarrative.com/ ");
		}
		else {
			System.out.println("Search term NOT returned first and NOT points to https://trunarrative.com/ ");
		}
		
	}
	public void hitUrl() {
		try
		{
			List<WebElement> results = driver.findElements(By.id("search"));
			
			WebElement b = results.get(0);
			WebElement resUrlTag = b.findElement(By.tagName("cite"));	
			resUrlTag.click();

			System.out.println("User hits the url");
		}
		catch(Exception e)
		{
			System.out.println("Error:" + e);
		}
	}
	public void websiteNavigation() {
		try
		{
			String expectedTitle = "TruNarrative | Who, What and When | Fraud and Compliance Risk Solution";
			String actualTitle = "";
			actualTitle = driver.getTitle();
			if (actualTitle.contentEquals(expectedTitle)){
	            System.out.println("user is successfully navigated to the TruNarrative homepage");
	        } else {
	            System.out.println("user is NOT successfully navigated to the TruNarrative homepage");
	        }
			
		}
		catch(Exception e)
		{
			System.out.println("Error:" + e);
		}
	}
	public void checkStrapLine() {
		try
		{
			WebElement a = driver.findElement(By.id("main-content-wrapper"));
			WebElement lineTag = a.findElement(By.tagName("h4"));
			String actualStrapLine = lineTag.getText();
			String expectedStrapLine = "Easy Onboarding.  Smooth Transactions.  Insightful Compliance." ;
			if (actualStrapLine.contentEquals(expectedStrapLine)){
	            System.out.println("Verified the display of strap line");
	        } else {
	            System.out.println("Strap line is NOT displayed");
	        }
		}
		catch(Exception e)
		{
			System.out.println("Error:" + e);
		}
	}
	public void hitMore() {
		try
		{
			WebElement more = driver.findElement(By.id("menu-item-6055"));
			
			more.click();
			System.out.println("Verified the More link is clicked");
		}
		catch(Exception e)
		{
			System.out.println("Error:" + e);
		}
	}
	public void hitTrunarrativeTeam() {
		try
		{
		
			WebElement moreLink = driver.findElement(By.id("menu-item-6388"));
			
			moreLink.click();
			System.out.println("Verified the Trunarrative team link is clicked");
		}
		catch(Exception e)
		{
			System.out.println("Error:" + e);
		}
	}
	public void checkTeamCount() {
		try
		{
			//WebElement teamMembersDom = driver.findElement(By.className("stack-img-content"));
			List<WebElement> teamCount = driver.findElements(By.className("stack-img-content"));
			teamCount.size();
			System.out.println("Team count" + teamCount.size());
		}
		catch(Exception e)
		{
			System.out.println("Error:" + e);
		}
	}
	public void checkRoles() {
		try
		{	
			List<WebElement> teamCount = driver.findElements(By.className("stack-img-content"));
			
			for(int i=0; i< teamCount.size(); i++) {
				if(teamCount.get(i).getText().contains("John Lord")) {
					WebElement role = teamCount.get(i).findElement(By.tagName("p"));
					if(role.getText().contentEquals("Founder & CEO")) {
						
						System.out.println("Verified the role of John Lord is "+ role.getText());
					}
				}
				if(teamCount.get(i).getText().contains("David Eastaugh")) {
					WebElement role = teamCount.get(i).findElement(By.tagName("p"));
					
					if(role.getText().contains("Chief Technology Officer")) {
						
						System.out.println("Verified the role of David Eastaugh is "+ role.getText());
					}
				}
				if(teamCount.get(i).getText().contains("Nicola Janney")) {
					WebElement role = teamCount.get(i).findElement(By.tagName("p"));
					
					if(role.getText().contains("Human Resources Manager")) {
						
						System.out.println("Verified the role of Nicola Janney is "+role.getText() );
					}
				}
			}
		}
				catch(Exception e)
				{
					System.out.println("Error:" + e);
				}

				
	}
}
			
			

			
		
	

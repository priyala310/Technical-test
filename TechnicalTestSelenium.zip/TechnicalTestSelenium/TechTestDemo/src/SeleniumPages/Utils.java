package SeleniumPages;

import Common.BasePage;
import junitparams.Parameters;
import junitparams.JUnitParamsRunner;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.junit.runners.Parameterized.Parameter;

import net.bytebuddy.asm.Advice.Enter;
import net.bytebuddy.asm.Advice.Return;

import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.swing.JFileChooser;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import org.openqa.selenium.TakesScreenshot;
import java.io.File;

//import org.apache.commons.io.FileUtils;

import org.openqa.selenium.OutputType;
public class Utils extends BasePage{

	
	public void launchBrowser() {
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumProject\\TechnicalTestSelenium\\chromedriverpath\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
		
	}
	
	public void openSearchEngine() {
		String appUrl = "https://www.google.com";
		driver.get(appUrl);
		driver.manage().window().maximize();
		try {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			takeSnapShot(driver,"C://Screenshots//SearchEngine.png") ;
		} catch (Exception e) {
			System.out.println("Error:" + e);
		} 
	}
	
	public  void executeSearch(String searchTerm) {
		try
		{
			WebElement searchField = driver.findElement(By.name("q"));
			searchField.sendKeys(searchTerm);
			WebElement searchButton = driver.findElement(By.name("btnK"));
			searchButton.click();
		    WebElement searchResults =  driver.findElement(By.id("resultStats"));
		    Thread.sleep(8000);
		   
		    if(searchResults.isDisplayed()) {
		    	System.out.println("Keyword Search is executed");
		    } else {
	            System.out.println("Keyword Search is NOT executed");
		    }
		  
		}
		catch(Exception e)
		{
			System.out.println("Error in performing keyword search");
		}
	}
	//To verify the Search term returned first and it points to https://trunarrative.com/
	public void searchTermReturnedFirst(String url) {
		try {
			List<WebElement> results = driver.findElements(By.id("search"));
			
			WebElement b = results.get(0);
			
			
			WebElement resUrlTag = b.findElement(By.tagName("cite"));
			String resUrl = resUrlTag.getText();
			System.out.println("first search result url" + resUrl);
			 highLighterMethod(driver,b);
			 takeSnapShot(driver,"C://Screenshots//SearchTermReturnedFirst.png") ;
			Assert.assertEquals(url, resUrl);
			System.out.println("Search term returned first and it points to https://trunarrative.com/ ");
			
			
		}
		catch(AssertionError | Exception e)
		{
			System.out.println("Error in keyword search" + e);
		}
		
	}
	
	public void hitUrl() {
		try
		{
			List<WebElement> results = driver.findElements(By.id("search"));
			
			WebElement b = results.get(0);
			
			WebElement resUrlTag = b.findElement(By.tagName("cite"));
			highLighterMethod(driver,resUrlTag);
			resUrlTag.click();

			System.out.println("User hits the url");
		}
		catch(Exception e)
		{
			System.out.println("Error:" + e);
		}
	}
//Navigation to homepage
	public void websiteNavigation() {
		try
		{
			String expectedTitle = "TruNarrative | Who, What and When | Fraud and Compliance Risk Solution";
			String actualTitle = "";
			Thread.sleep(8000);
			actualTitle = driver.getTitle();
			if (actualTitle.contentEquals(expectedTitle)){
	            System.out.println("user is successfully navigated to the TruNarrative homepage");
	        } else {
	            System.out.println("user is NOT successfully navigated to the TruNarrative homepage");
	        }
			takeSnapShot(driver,"C://Screenshots//HomePageLoaded.png") ;
		}
		catch(Exception e)
		{
			System.out.println("Error:" + e);
		}
	}
	//To verify the strap line
	public void checkStrapLine() {
		try
		{
			WebElement a = driver.findElement(By.id("main-content-wrapper"));
			WebElement lineTag = a.findElement(By.tagName("h4"));
			highLighterMethod(driver, lineTag);
			String actualStrapLine = lineTag.getText();
			String expectedStrapLine = "Easy Onboarding.  Smooth Transactions.  Insightful Compliance." ;
			if (actualStrapLine.contentEquals(expectedStrapLine)){
	            System.out.println("Verified the display of strap line");
	        } else {
	            System.out.println("Strap line is NOT displayed");
	        }
			takeSnapShot(driver,"C://Screenshots//StrapLineCheck.png") ;
		}
		catch(Exception e)
		{
			System.out.println("Error:" + e);
		}
	}

	public void hitMore() {
		try
		{
			WebElement more = driver.findElement(By.id("menu-item-6055"));
			Thread.sleep(8000);
			highLighterMethod(driver, more);
			more.click();
			System.out.println("Verified the More link is clicked");
			takeSnapShot(driver,"C://Screenshots//MoreLinkHit.png") ;
		}
		catch(Exception e)
		{
			System.out.println("Error:" + e);
		}
	}

	public void hitTrunarrativeTeam() {
		try
		{
		
			WebElement moreLink = driver.findElement(By.id("menu-item-6388"));
			Thread.sleep(8000);
			highLighterMethod(driver, moreLink);
			moreLink.click();
			System.out.println("Verified the Trunarrative team link is clicked");
			takeSnapShot(driver,"C://Screenshots//TrunNarrativeTeam.png") ;
		}
		catch(Exception e)
		{
			System.out.println("Error:" + e);
		}
	}
//To check team count
	public void checkTeamCount() {
		try
		{
			List<WebElement> teamCount = driver.findElements(By.className("stack-img-content"));
			teamCount.size();
			System.out.println("Team count" + teamCount.size());
			takeSnapShot(driver,"C://Screenshots//LeadershipTeam.png") ;
		}
		catch(Exception e)
		{
			System.out.println("Error:" + e);
		}
	}
//To Verify the roles
	public void checkRoles() {
		try
		{	
			List<WebElement> teamCount = driver.findElements(By.className("stack-img-content"));
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("window.scrollBy(0,250)", "");
			takeSnapShot(driver,"C://Screenshots//JohnLordRole.png") ;
			for(int i=0; i< teamCount.size(); i++) {
				if(teamCount.get(i).getText().contains("John Lord")) {
					WebElement role = teamCount.get(i).findElement(By.tagName("p"));
					if(role.getText().contentEquals("Founder & CEO")) {
						
						System.out.println("Verified the role of John Lord is "+ role.getText());
					}
				}
				
				if(teamCount.get(i).getText().contains("David Eastaugh")) {
					WebElement role = teamCount.get(i).findElement(By.tagName("p"));
					
					if(role.getText().contains("Chief Technology Officer")) {
						
						System.out.println("Verified the role of David Eastaugh is "+ role.getText());
					}
				}
				
				if(teamCount.get(i).getText().contains("Nicola Janney")) {
					WebElement role = teamCount.get(i).findElement(By.tagName("p"));
					
					if(role.getText().contains("Human Resources Manager")) {
						
						System.out.println("Verified the role of Nicola Janney is "+role.getText() );
					}
				}
				
			}
			jse.executeScript("window.scrollBy(0,915)", "");
			Thread.sleep(3000);
			takeSnapShot(driver,"C://Screenshots//DavidEastaughRole.png") ;
			jse.executeScript("window.scrollBy(0,925)", "");
			takeSnapShot(driver,"C://Screenshots//NicolaJannneyRole.png") ;
		}
				catch(Exception e)
				{
					System.out.println("Error:" + e);
				}

				
	}
	
	//Common method to highlight the elements
	public void highLighterMethod(WebDriver driver, WebElement element){
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
		 }
	//To capture screenshots
	 public static void takeSnapShot(WebDriver driver,String filePath) throws Exception{

		 File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);			
		 File currPath = new File(filePath);
		 FileHandler.copy(scrFile,  currPath );
			
	 }
	public void closeBrowser(){
		driver.close();
	 }
}
			
			

			
		
	
